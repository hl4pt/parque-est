from keras.models import load_model
import cv2
import numpy as np

# carregar o modelo de classificação
# foi treinado usando o google teachablemachine
# https://teachablemachine.withgoogle.com/train
# o modelo que pode ser carregado com o keras (tensorflow)
model = load_model('model/keras_model_old.h5', compile=False)


def model_tf(frame=None):
    # resize para 224x224 do tamanho do frame (o modelo keras foi treinado com estes parametros)
    inp = cv2.resize(frame, dsize=(224, 224), interpolation=cv2.INTER_CUBIC)

    # converter o input em numpy array
    np_image_data = np.asarray(inp)

    # ajustar as dimensoes da nossa array, para o modelo precisamos de uma
    # shape de (1, x)
    np_final = np.expand_dims(np_image_data, axis=0)

    # prever o resultado do frame atual
    prediction = model.predict(np_final)[0][0]

    return prediction